package test;

public class XorO {
	public String XorO;

	public XorO(String XorO) {
		this.XorO = XorO;
	}

	public String getString() {
		return XorO;
	}

	public void changeString(String newXorO) {
		XorO = newXorO;
	}
}
